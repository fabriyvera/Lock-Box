"use client";

import React, { useState } from "react";
import { useBuyerStore } from "@/lib/buyer/connected-store";
import { calculateCartSubtotal, formatBOB } from "@/lib/buyer/domain";
import { Modal } from "./ui";
import {
  ShieldCheck,
  MapPin,
  Smartphone,
  Landmark,
  CheckCircle2,
} from "lucide-react";
import { BuyerOrder } from "@/lib/buyer/model";

export function CheckoutModal({
  isOpen,
  onClose,
  onOrderSuccess,
}: {
  isOpen: boolean;
  onClose: () => void;
  onOrderSuccess: (order: BuyerOrder) => void;
}) {
  const [state, actions, meta] = useBuyerStore();
  const [selectedPointId, setSelectedPointId] = useState<string>(
    state.lockBoxPoints[0]?.id || "",
  );
  const [paymentMethod, setPaymentMethod] = useState<"yape" | "bcp">("yape");
  const [isProcessing, setIsProcessing] = useState(false);

  const subtotal = calculateCartSubtotal(state.cart);
  const pointId = state.lockBoxPoints.some(
    (point) => point.id === selectedPointId,
  )
    ? selectedPointId
    : (state.lockBoxPoints[0]?.id ?? "");

  const handleConfirmPayment = async () => {
    if (!pointId || isProcessing) return;
    setIsProcessing(true);
    try {
      const order = await actions.checkout(pointId, paymentMethod);
      setIsProcessing(false);
      if (order) {
        onClose();
        onOrderSuccess(order);
      }
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        if (!isProcessing) onClose();
      }}
      title="Compra de prueba conectada"
    >
      <div className="space-y-5">
        {/* Banner de protección Escrow */}
        <div className="bg-accent/10 border border-accent/30 rounded-lg p-3.5 flex items-start gap-3">
          <ShieldCheck
            aria-hidden="true"
            className="w-5 h-5 text-accent shrink-0 mt-0.5"
          />
          <div className="text-xs space-y-1">
            <p className="font-bold text-accent uppercase tracking-wider">
              Simulación de pago protegido
            </p>
            <p className="text-text-secondary leading-relaxed">
              Se creará un pedido de prueba en el sistema para que el vendedor
              lo despache y el punto confirme la entrega. No se retienen fondos.
            </p>
          </div>
        </div>

        {/* Selección de Punto LockBox */}
        <fieldset disabled={isProcessing || meta.busy}>
          <legend className="block text-xs font-bold uppercase tracking-wider text-text-secondary mb-2">
            1. Selecciona tu Punto LockBox de entrega
          </legend>
          <div className="space-y-2">
            {state.lockBoxPoints.map((point) => (
              <label
                key={point.id}
                className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                  pointId === point.id
                    ? "border-accent bg-surface-raised"
                    : "border-border bg-canvas hover:border-border-strong"
                }`}
              >
                <input
                  autoComplete="off"
                  type="radio"
                  name="lockbox_point"
                  value={point.id}
                  checked={pointId === point.id}
                  onChange={() => setSelectedPointId(point.id)}
                  className="mt-1 accent-accent"
                />
                <div className="flex-1 text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-foreground">
                    <MapPin
                      aria-hidden="true"
                      className="w-3.5 h-3.5 text-accent"
                    />
                    {point.name}
                  </div>
                  <p className="text-text-muted mt-0.5">{point.address}</p>
                  <p className="text-text-subtle text-xs mt-1 font-mono">
                    Tel: {point.phone} • Capacidad: {point.capacity} casilleros
                  </p>
                </div>
              </label>
            ))}
          </div>
        </fieldset>

        {/* Método de Pago */}
        <fieldset disabled={isProcessing || meta.busy}>
          <legend className="block text-xs font-bold uppercase tracking-wider text-text-secondary mb-2">
            2. Método de pago simulado
          </legend>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setPaymentMethod("yape")}
              aria-pressed={paymentMethod === "yape"}
              className={`p-3 rounded-lg border text-xs font-bold flex flex-col items-center gap-1.5 transition-colors cursor-pointer ${
                paymentMethod === "yape"
                  ? "border-accent bg-surface-raised text-foreground"
                  : "border-border bg-canvas text-text-muted"
              }`}
            >
              <span className="text-sm flex items-center gap-2">
                <Smartphone size={16} aria-hidden="true" /> Yape Bolivia
              </span>
              <span className="text-xs text-text-subtle font-normal">
                QR Simple
              </span>
            </button>
            <button
              type="button"
              onClick={() => setPaymentMethod("bcp")}
              aria-pressed={paymentMethod === "bcp"}
              className={`p-3 rounded-lg border text-xs font-bold flex flex-col items-center gap-1.5 transition-colors cursor-pointer ${
                paymentMethod === "bcp"
                  ? "border-accent bg-surface-raised text-foreground"
                  : "border-border bg-canvas text-text-muted"
              }`}
            >
              <span className="text-sm flex items-center gap-2">
                <Landmark size={16} aria-hidden="true" /> BCP Banca Móvil
              </span>
              <span className="text-xs text-text-subtle font-normal">
                Transferencia QR
              </span>
            </button>
          </div>
        </fieldset>

        {/* Resumen Final */}
        <div className="border-t border-border pt-4 space-y-2">
          <div className="flex justify-between text-xs text-text-muted">
            <span>Productos ({state.cart.length})</span>
            <span>{formatBOB(subtotal)}</span>
          </div>
          <div className="flex justify-between text-xs text-text-muted">
            <span>Custodia Escrow</span>
            <span className="text-accent font-bold">Gratis</span>
          </div>
          <div className="flex justify-between text-sm font-bold text-foreground pt-1 border-t border-border/60">
            <span>Total de prueba</span>
            <span className="text-accent font-mono text-base">
              {formatBOB(subtotal)}
            </span>
          </div>
        </div>

        {meta.error && (
          <p role="alert" className="text-sm text-danger">
            {meta.error}
          </p>
        )}
        {!pointId && <p role="alert">No hay puntos de recojo disponibles.</p>}
        {/* Botón de Confirmación */}
        <button
          type="button"
          disabled={
            isProcessing || meta.busy || !pointId || state.cart.length === 0
          }
          onClick={handleConfirmPayment}
          aria-busy={isProcessing}
          className="w-full bg-accent hover:bg-accent-hover text-on-accent font-black text-xs uppercase tracking-wider py-3.5 rounded flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-50"
        >
          {isProcessing ? (
            "Creando pedido de prueba…"
          ) : (
            <>
              <CheckCircle2 aria-hidden="true" className="w-4 h-4" />
              Confirmar compra de prueba
            </>
          )}
        </button>
      </div>
    </Modal>
  );
}
