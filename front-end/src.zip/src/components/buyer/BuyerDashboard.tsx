"use client";

import React, { useState } from "react";
import Link from "next/link";
import { BuyerStoreProvider, useBuyerStore } from "@/lib/buyer/connected-store";
import { CatalogPanel } from "./CatalogPanel";
import { CartDrawer } from "./CartDrawer";
import { CheckoutModal } from "./CheckoutModal";
import { OrdersPanel } from "./OrdersPanel";
import {
  ShoppingBag,
  Package,
  RotateCcw,
  LogOut,
  LoaderCircle,
} from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { useWorkspaceView } from "@/components/workspace/useWorkspaceView";
import styles from "./workspace.module.css";

export function BuyerDashboard({ name }: { name: string }) {
  return (
    <BuyerStoreProvider>
      <BuyerWorkspace name={name} />
    </BuyerStoreProvider>
  );
}

function BuyerWorkspace({ name }: { name: string }) {
  const [state, actions, meta] = useBuyerStore();
  const {
    view: activeTab,
    navigate: setActiveTab,
    follow,
  } = useWorkspaceView(["catalog", "orders"] as const, "catalog");
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [logoutError, setLogoutError] = useState<string | null>(null);
  const [loggingOut, setLoggingOut] = useState(false);

  const totalCartItems = state.cart.reduce(
    (sum, item) => sum + item.quantity,
    0,
  );

  const handleOrderSuccess = () => {
    setActiveTab("orders");
  };

  async function logout() {
    if (loggingOut) return;
    setLoggingOut(true);
    try {
      const { error } = await createClient().auth.signOut();
      if (error) throw error;
      window.location.replace("/login");
    } catch {
      setLogoutError("No se pudo cerrar sesión.");
      setLoggingOut(false);
    }
  }

  return (
    <div
      className={`app-theme ${styles.workspace} min-h-screen bg-canvas text-foreground flex flex-col font-sans`}
    >
      <a href="#buyer-content" className="workspace-skip-link">
        Saltar al contenido
      </a>
      {/* NAVBAR */}
      <header className="border-b border-border px-4 md:px-8 py-3.5 bg-canvas/90 backdrop-blur sticky top-0 z-40 flex flex-wrap gap-3 items-center justify-between">
        <div className="flex flex-wrap items-center gap-3 sm:gap-6">
          <Link
            href="/"
            className="flex items-center"
            aria-label="LockBox, volver al inicio"
          >
            <span className="bg-accent text-on-accent font-black px-2 py-0.5 text-sm rounded-l tracking-wider">
              LOCK
            </span>
            <span className="bg-surface border border-border text-foreground font-bold px-2 py-0.5 text-sm rounded-r tracking-wider">
              BOX
            </span>
          </Link>

          <nav
            className="flex flex-wrap items-center gap-1 text-xs"
            aria-label="Módulo del comprador"
          >
            <a
              href="?vista=catalog"
              onClick={(event) => follow(event, "catalog")}
              aria-current={activeTab === "catalog" ? "page" : undefined}
              className={`px-3 py-1.5 rounded font-bold transition-colors cursor-pointer ${
                activeTab === "catalog"
                  ? "bg-surface-raised text-accent"
                  : "text-text-muted hover:text-foreground"
              }`}
            >
              Catálogo & Live
            </a>
            <a
              href="?vista=orders"
              onClick={(event) => follow(event, "orders")}
              aria-current={activeTab === "orders" ? "page" : undefined}
              className={`px-3 py-1.5 rounded font-bold transition-colors flex items-center gap-1.5 cursor-pointer ${
                activeTab === "orders"
                  ? "bg-surface-raised text-accent"
                  : "text-text-muted hover:text-foreground"
              }`}
            >
              <Package aria-hidden="true" className="w-3.5 h-3.5" />
              Mis Pedidos ({state.orders.length})
            </a>
          </nav>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => void actions.refresh()}
            disabled={meta.busy || meta.loading}
            title="Actualizar catálogo y pedidos"
            aria-label="Actualizar catálogo y pedidos"
            className="p-2 text-text-subtle hover:text-foreground transition-colors"
          >
            <RotateCcw aria-hidden="true" className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsCartOpen(true)}
            aria-label={`Abrir carrito, ${totalCartItems} artículos`}
            className="flex items-center gap-2 bg-surface border border-border hover:border-accent px-3.5 py-2 rounded text-xs font-bold text-foreground transition-colors cursor-pointer relative"
          >
            <ShoppingBag aria-hidden="true" className="w-4 h-4 text-accent" />
            <span className="hidden sm:inline">Carrito</span>
            {totalCartItems > 0 && (
              <span className="bg-accent text-on-accent text-xs font-black px-1.5 py-0.2 rounded-full">
                {totalCartItems}
              </span>
            )}
          </button>
          <button
            disabled={loggingOut}
            onClick={() => void logout()}
            className="flex items-center gap-2 text-xs text-text-muted"
          >
            <LogOut size={16} aria-hidden="true" /> Cerrar sesión
          </button>
        </div>
      </header>

      {/* CONTENIDO PRINCIPAL */}
      <main
        id="buyer-content"
        tabIndex={-1}
        className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-8"
      >
        <div className={styles.pageHeading}>
          <div>
            <p className={styles.eyebrow}>ESPACIO DEL COMPRADOR</p>
            <h1>
              {activeTab === "catalog"
                ? "Encuentra tu próxima compra"
                : "Sigue tus pedidos"}
            </h1>
            <p>Hola, {name}. Compra y recoge en tu punto LockBox.</p>
          </div>
        </div>
        <div className="mb-5 rounded-lg border border-accent/25 bg-accent/5 p-4 text-sm text-text-secondary">
          <strong className="text-accent">
            Hola, {name}. Compras de prueba conectadas.
          </strong>{" "}
          Tu catálogo, carrito y pedidos se sincronizan con el sistema. Las
          compras de prueba llegan al vendedor y al punto de recojo; no se cobra
          ni se mueve dinero real.
        </div>
        {meta.error && (
          <p role="alert" className="mb-4 text-danger">
            {meta.error}
          </p>
        )}
        {meta.loading && <p role="status">Cargando catálogo y pedidos…</p>}
        {meta.busy && (
          <p
            role="status"
            className="flex items-center gap-2 py-3 text-text-muted"
          >
            <LoaderCircle
              aria-hidden="true"
              size={18}
              className="animate-spin motion-reduce:animate-none"
            />
            Guardando cambio…
          </p>
        )}
        {logoutError && (
          <p role="alert" className="mb-4 text-danger">
            {logoutError}
          </p>
        )}
        {activeTab === "catalog" ? <CatalogPanel /> : <OrdersPanel />}
      </main>

      {/* DRAWERS Y MODALES */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onOpenCheckout={() => setIsCheckoutOpen(true)}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        onOrderSuccess={handleOrderSuccess}
      />
    </div>
  );
}

export default BuyerDashboard;
